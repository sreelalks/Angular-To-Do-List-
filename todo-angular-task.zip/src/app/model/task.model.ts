export interface Task {
    title: string;
    status: boolean;
}